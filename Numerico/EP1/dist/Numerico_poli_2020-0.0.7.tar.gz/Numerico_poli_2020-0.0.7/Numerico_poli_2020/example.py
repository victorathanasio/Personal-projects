from Numerico_poli_2020 import Simu
Simu.simu = 'a'

from Numerico_poli_2020 import he_solver

#%%
a = he_solver.he_solver(1, 0.5, 3)
a.execute_euler()